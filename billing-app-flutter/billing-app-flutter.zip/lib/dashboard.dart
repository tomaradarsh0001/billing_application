import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:google_fonts/google_fonts.dart';
import 'customerview.dart';
import 'colors.dart';
import 'package:flutter/services.dart';  // To load the SVG as a string

class DashboardPage extends StatefulWidget {
  @override
  _DashboardPageState createState() => _DashboardPageState();
}
class _DashboardPageState extends State<DashboardPage> {
  bool _isAnimationComplete = false;
  int _currentIndex = 0;
  String svgString = '';
  Color? primaryLight;
  Color? secondaryLight; // Assuming color2 is also a dynamic color
  Color? primaryDark; // Assuming color3 is also a dynamic color
  double _tileOpacity = 0; // Start opacity is 0.2
  double _avatarOpacity = 0;

  @override
  void initState() {
    super.initState();
    AppColors.fetchColors().then((_) {
      setState(() {
        secondaryLight = AppColors.secondaryLight;
        primaryLight = AppColors.primaryLight; // Replace with actual dynamic color
        primaryDark = AppColors.primaryDark; // Replace with actual dynamic color
      });

      // Load SVG after colors are fetched
      loadSvg();
    });
    Future.delayed(Duration(milliseconds: 100), () {
      setState(() {
        _tileOpacity = 1.0; // Transition tiles opacity to 1.0
        _avatarOpacity = 1.0; // Transition avatar opacity to 1.0
      });
    });
    // Animation completion state
    Future.delayed(Duration(milliseconds: 200), () {
      setState(() {
        _isAnimationComplete = true;
      });
    });
  }
  void _onItemTapped(int index) {
    setState(() {
      _currentIndex = index;
    });

    // Navigate to DashboardPage when Home button is tapped (index 0)
    if (index == 0) {
      // Navigator.push(
      //   context,
      //   MaterialPageRoute(builder: (context) => DashboardPage()),
      // );
    }
  }
  // Function to load the SVG and replace placeholders
  Future<void> loadSvg() async {
    if (secondaryLight != null && primaryLight != null && primaryDark != null) {
      String svg = await rootBundle.loadString('assets/dashboard_upper_shape.svg');
      setState(() {
        // Replace placeholders with actual colors in hex format
        svgString = svg.replaceAll(
          'PLACEHOLDER_COLOR_1', _colorToHex(secondaryLight!),
        ).replaceAll(
          'PLACEHOLDER_COLOR_2', _colorToHex(primaryLight!),
        ).replaceAll(
          'PLACEHOLDER_COLOR_3', _colorToHex(primaryDark!),
        );
      });
    }
  }
  // Helper function to convert Color to Hex string
  String _colorToHex(Color color) {
    return '#${color.value.toRadixString(16).substring(2).toUpperCase()}';
  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: Stack(
        children: [
          // Top Background Shape
          AnimatedPositioned(
            duration: const Duration(milliseconds: 1500),
            curve: Curves.easeInOut,
            top: _isAnimationComplete ? 0 : -400,
            left: 0,
            right: 0,
            child: SvgPicture.string(
              svgString,  // Render the modified SVG string with new colors
              semanticsLabel: 'Animated and Colored SVG',
              fit: BoxFit.fill,
              height: 300,  // Height of the SVG
            )
          ),

          // Main Content
          Padding(
            padding: const EdgeInsets.only(top: 90),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Welcome Message
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 20.0),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            "Welcome, Adarsh",
                            style: GoogleFonts.signika(
                              fontSize: 18,
                              fontWeight: FontWeight.w500,
                              color: Colors.white,
                            ),
                          ),
                          Text(
                            "Dashboard",
                            style: GoogleFonts.signika(
                              fontSize: 30,
                              fontWeight: FontWeight.bold,
                              color: Colors.white,
                            ),
                          ),
                          Text(
                            "Logged in with: tomaradarsh001@gmail.com",
                            style: GoogleFonts.signika(
                              fontSize: 10,
                              color: Colors.white.withOpacity(0.9),
                            ),
                          ),
                        ],
                      ),
                      AnimatedOpacity(
                        opacity: _avatarOpacity, // Use _avatarOpacity for CircleAvatar
                        duration: Duration(seconds: 1),
                        curve: Curves.easeInOut,
                        child: CircleAvatar(
                          radius: 30,
                          backgroundColor: Colors.transparent,
                          child: Image.asset(
                            'assets/dashboard_user.png', // Replace with actual path to your PNG file
                            width: 60,
                            height: 60,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 20),
                // Scrollable Grid of Dashboard Tiles
                Expanded(
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 40.0),
                    child: SingleChildScrollView(
                      child: GridView.count(
                        shrinkWrap: true, // Makes sure the GridView does not take up more space than needed
                        physics: NeverScrollableScrollPhysics(), // Disables scrolling of GridView
                        crossAxisCount: 2,
                        mainAxisSpacing: 20,
                        crossAxisSpacing: 20,
                        children: [
                          _buildDashboardTile("Profile", Icons.person),
                          _buildDashboardTile("Customers", Icons.group),
                          _buildDashboardTile("Configurations", Icons.build),
                          _buildDashboardTile("History", Icons.history),
                          _buildDashboardTile("Bills", Icons.receipt_long),
                          _buildDashboardTile("Settings", Icons.settings),
                        ],
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
      bottomNavigationBar: Container(
        decoration: BoxDecoration(
          border: Border(
            top: BorderSide(color: Color(0xFFDEDDDD), width: 1), // Upper black border
          ),
        ),
        child: BottomNavigationBar(
          backgroundColor: Colors.white,
          currentIndex: _currentIndex,
          onTap: _onItemTapped,
          type: BottomNavigationBarType.fixed,
          selectedFontSize: 0,
          unselectedFontSize: 0,
          items: [
            BottomNavigationBarItem(
              icon: SizedBox(
                height: kBottomNavigationBarHeight,
                child: Center(
                  child: SvgPicture.asset(
                    'assets/home.svg',
                    width: 24,
                    height: 24,
                    color: _currentIndex == 0 ? primaryDark : Colors.grey,
                  ),
                ),
              ),
              label: "",
            ),
            BottomNavigationBarItem(
              icon: SizedBox(
                height: kBottomNavigationBarHeight,
                child: Center(
                  child: SvgPicture.asset(
                    'assets/search.svg',
                    width: 24,
                    height: 24,
                    color: _currentIndex == 1 ? primaryDark : Colors.grey,
                  ),
                ),
              ),
              label: "",
            ),
            BottomNavigationBarItem(
              icon: SizedBox(
                height: kBottomNavigationBarHeight,
                child: Center(
                  child: SvgPicture.asset(
                    'assets/settings.svg',
                    width: 24,
                    height: 24,
                    color: _currentIndex == 2 ? primaryDark  : Colors.grey,
                  ),
                ),
              ),
              label: "",
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildDashboardTile(String title, IconData icon) {
    return Material(
      color: Colors.transparent,
      borderRadius: BorderRadius.circular(24),
      child: InkWell(
        borderRadius: BorderRadius.circular(24),
        onTap: () {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => CustomerViewPage(),
            ),
          );
        },
        splashColor: Colors.blue.withOpacity(0.2),
        child: AnimatedOpacity(
          opacity: _tileOpacity, // Use _tileOpacity to control opacity
          duration: Duration(seconds: 2),
          curve: Curves.easeInOut,
          child: Container(
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(24),
              boxShadow: [
                BoxShadow(
                  color: Colors.grey.withOpacity(0.4),
                  blurRadius: 15,
                  offset: Offset(2, 9),
                ),
              ],
            ),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(icon, size: 70, color: primaryDark ?? Colors.transparent),
                SizedBox(height: 0),
                Text(
                  title,
                  style: GoogleFonts.signika(
                    fontSize: 14,
                    fontWeight: FontWeight.w500,
                    color: Colors.grey,
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

}
