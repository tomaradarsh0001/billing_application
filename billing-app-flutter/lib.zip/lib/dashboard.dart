import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:google_fonts/google_fonts.dart';
import 'customerview.dart';

class DashboardPage extends StatefulWidget {
  @override
  _DashboardPageState createState() => _DashboardPageState();
}

class _DashboardPageState extends State<DashboardPage> {
  bool _isAnimationComplete = false;
  int _currentIndex = 0;

  @override
  void initState() {
    super.initState();
    Future.delayed(Duration(milliseconds: 200), () {
      setState(() {
        _isAnimationComplete = true;
      });
    });
  }

  void _onItemTapped(int index) {
    setState(() {
      _currentIndex = index;
    });

    // Navigate to DashboardPage when Home button is tapped (index 0)
    if (index == 0) {
      Navigator.push(
        context,
        MaterialPageRoute(builder: (context) => DashboardPage()),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: Stack(
        children: [
          // Top Background Shape
          AnimatedPositioned(
            duration: const Duration(milliseconds: 900),
            curve: Curves.easeInOut,
            top: _isAnimationComplete ? 0 : -400,
            left: 0,
            right: 0,
            child: SvgPicture.asset(
              'assets/dashboard_upper_shape.svg', // Replace with your asset
              fit: BoxFit.fill,
              height: 300,
            ),
          ),
          // Main Content
          Padding(
            padding: const EdgeInsets.only(top: 90),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Welcome Message
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 20.0),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            "Welcome, Adarsh",
                            style: GoogleFonts.signika(
                              fontSize: 18,
                              fontWeight: FontWeight.w500,
                              color: Colors.white,
                            ),
                          ),
                          Text(
                            "Dashboard",
                            style: GoogleFonts.signika(
                              fontSize: 30,
                              fontWeight: FontWeight.bold,
                              color: Colors.white,
                            ),
                          ),
                          Text(
                            "Logged in with: tomaradarsh001@gmail.com",
                            style: GoogleFonts.signika(
                              fontSize: 10,
                              color: Colors.white.withOpacity(0.9),
                            ),
                          ),
                        ],
                      ),
                      CircleAvatar(
                        radius: 30,
                        backgroundColor: Colors.transparent,
                        child: Image.asset(
                          'assets/dashboard_user.png', // Replace with the actual path to your PNG file
                          width: 60,
                          height: 60,
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 20),
                // Scrollable Grid of Dashboard Tiles
                Expanded(
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 40.0),
                    child: SingleChildScrollView(
                      child: GridView.count(
                        shrinkWrap: true, // Makes sure the GridView does not take up more space than needed
                        physics: NeverScrollableScrollPhysics(), // Disables scrolling of GridView
                        crossAxisCount: 2,
                        mainAxisSpacing: 20,
                        crossAxisSpacing: 20,
                        children: [
                          _buildDashboardTile("Profile", Icons.person),
                          _buildDashboardTile("Customers", Icons.group),
                          _buildDashboardTile("Configurations", Icons.build),
                          _buildDashboardTile("History", Icons.history),
                          _buildDashboardTile("Bills", Icons.receipt_long),
                          _buildDashboardTile("Settings", Icons.settings),
                        ],
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
      bottomNavigationBar: Container(
        decoration: BoxDecoration(
          border: Border(
            top: BorderSide(color: Color(0xFFDEDDDD), width: 1), // Upper black border
          ),
        ),
        child: BottomNavigationBar(
          backgroundColor: Colors.white,
          currentIndex: _currentIndex,
          onTap: _onItemTapped,
          type: BottomNavigationBarType.fixed,
          selectedFontSize: 0,
          unselectedFontSize: 0,
          items: [
            BottomNavigationBarItem(
              icon: SizedBox(
                height: kBottomNavigationBarHeight,
                child: Center(
                  child: SvgPicture.asset(
                    'assets/home.svg',
                    width: 24,
                    height: 24,
                    color: _currentIndex == 0 ? Colors.blue : Colors.grey,
                  ),
                ),
              ),
              label: "",
            ),
            BottomNavigationBarItem(
              icon: SizedBox(
                height: kBottomNavigationBarHeight,
                child: Center(
                  child: SvgPicture.asset(
                    'assets/search.svg',
                    width: 24,
                    height: 24,
                    color: _currentIndex == 1 ? Colors.blue : Colors.grey,
                  ),
                ),
              ),
              label: "",
            ),
            BottomNavigationBarItem(
              icon: SizedBox(
                height: kBottomNavigationBarHeight,
                child: Center(
                  child: SvgPicture.asset(
                    'assets/settings.svg',
                    width: 24,
                    height: 24,
                    color: _currentIndex == 2 ? Colors.blue : Colors.grey,
                  ),
                ),
              ),
              label: "",
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildDashboardTile(String title, IconData icon) {
    return Material(
      color: Colors.transparent, // Ensures ripple effect is visible
      borderRadius: BorderRadius.circular(24),
      child: InkWell(
        borderRadius: BorderRadius.circular(24), // Matches the tile's border radius
        onTap: () {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => CustomerViewPage(),
            ),
          );
        },
        splashColor: Colors.blue.withOpacity(0.2), // Ripple effect color
        child: Container(
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(24),
            boxShadow: [
              BoxShadow(
                color: Colors.grey.withOpacity(0.4),
                blurRadius: 15,
                offset: Offset(2, 9),
              ),
            ],
          ),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(icon, size: 70, color: Colors.blue),
              SizedBox(height: 0),
              Text(
                title,
                style: GoogleFonts.signika(
                  fontSize: 14,
                  fontWeight: FontWeight.w500,
                  color: Colors.grey,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
